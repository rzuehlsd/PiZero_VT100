# Daily Change Log

Reconstructed from git commit history and intended as a concise daily summary of implemented features and codebase changes.

## Update Procedure
- Append only; do not rewrite prior daily sections unless correcting factual errors.
- Use one section per day in ISO format: `## YYYY-MM-DD`.
- For each day with implemented work, add exactly these two bullets:
	- `Implemented features: ...`
	- `Codebase changes: ...`
- Keep entries concise and based on completed, merged work.

## 2026-05-04
- Implemented features: made the modern setup dialog replace the current `host_id` value on the first typed character after selecting the remote shell target row while keeping backspace editing available.
- Codebase changes: added a small `CTSetup` edit-state flag for `host_id`, reset it on modern-dialog entry and row changes, kept the edited remote shell target visible when navigating to other config items, gated screen logger plus direct kernel/WLAN-host status output while setup dialogs are visible so no messages are painted over configuration screens, including the shell-client IPv4 validation warning, fixed `SaveToFile()` so `host_id` and `log_output` persist to the correct keys, hardened the renderer parser so a fresh `ESC` cleanly restarts an unfinished escape/CSI sequence, reset line attributes when `ED`/`EL` fully clear rows so `vttest` cursor-positioning tests no longer inherit stale double-width line state, fixed `RI` (`ESC M`) so it moves the cursor up inside the scroll region instead of only acting at the top margin, reset all line attributes at `DECALN` start so the screen-alignment pattern cannot preserve stale double-width state into `vttest` cursor-movement checks, implemented a logical `DECCOLM` 80/132-column mode that re-clamps the visible text grid on wide framebuffers, aligned the legacy `ESC[?3h/l` fallback parser path with the main CSI parser so both `vttest` column-mode passes use the same width-switch behavior, and normalized requested column modes to the physical text width so a fixed 80-column display does not retain a synthetic 132-column state after `ESC[?3h`.

## 2026-05-05
- Implemented features: tightened the VT100 `DECCOLM` reset so the second `vttest` cursor-movement pass now restarts from the same parser, cursor-motion, wrapping, and VT100 linefeed baseline as a fresh terminal page, documented that the 132-column second movement-test screen remains outside the hardware target because the current framebuffer/font combination can show only about 102 columns, corrected horizontal-tab behavior at the right margin for the `vttest` autowrap screen, taught the CSI parser to keep embedded cursor-control characters inside active escape sequences for the following `vttest` screen, documented that the 80-column tests in the first `vttest` VT100 section now pass, documented that the second `Screen Features` test passes apart from missing visible blink rendering, documented that `vttest` Character Sets test 3 passes with standard DEC ASCII plus DEC Special Graphics but without a DEC Alternate Character Set, and removed an accidental internal VTTest probe change that was not part of the external `vttest` fix.
- Codebase changes: updated `CTRenderer::ApplyColumnMode()` to preserve physical-width clamping while also restoring parser/CSI state, wraparound, VT100 default linefeed mode, charset selection, cursor visibility, font baseline, line attributes, and related motion state before the VT100-style full-screen clear sequence triggered by `ESC[?3h` or `ESC[?3l`; aligned the constructor and full terminal reset path to the same `LNM` default (`LF` as `IND` unless ANSI newline mode is explicitly enabled); clamped `HT` to the last visible column instead of forcing a newline when no further tab stop exists on the current row; executed embedded C0 controls such as `BS`, `CR`, `VT`, `LF`, and `TAB` inside an active CSI sequence without discarding the pending CSI parameters; added README notes that explain the `DECCOLM` geometry limit, the need for an actual `vttest` `max_cols` override, the now-correct 80-column status of the first `vttest` section, the remaining lack of visible text blinking in `Screen Features`, and the limited character-set coverage without a DEC Alternate Character Set; and reverted the temporary `VTTest.cpp` DECCOLM probe helpers/step wiring.

## 2026-01-12
- Implemented features: integrated `CScheduler` periodic/background tasks, added scheduler demo task, and moved keyboard/serial handling toward task-based processing.
- Codebase changes: refactored font selection and greeting rendering logic into renderer-focused code, added kernel/scheduler accessors, fixed build/link issues, and updated scope/docs.

## 2026-01-13
- Implemented features: integrated WLAN stack and telnet server with successful terminal connection testing.
- Codebase changes: removed custom scheduler usage, switched keyboard/serial flows to Circle scheduler tasks, and added WLAN console build/link dependencies.

## 2026-01-16
- Implemented features: added periodic task coverage for WLAN logging/terminal server activity.
- Codebase changes: performed broad documentation rework and partial output-device integration updates around `CLogDevice` behavior.

## 2026-01-20
- Implemented features: completed VT100 App 2.0 restructuring with renderer/font-converter integration and support for VT100 base/double-width/double-height font modes.
- Codebase changes: consolidated renderer pipeline around Circle `CTerminal`-based architecture with dynamic font handling.

## 2026-01-21
- Implemented features: added reverse video, underline/bold attribute handling, blinking cursor, and DEC/VT100 color/font escape-sequence behavior.
- Guarded raw renderer pixel access against out-of-bounds writes and restored Setup B to the stable header row while continuing the title alignment fix.
- Added a comparison build where Setup B calls `RenderHeader()` with the same parameters as Setup A to isolate whether the remaining title offset is caused by the header call itself.

## 2026-05-01
- Implemented features: stabilized legacy setup-header rendering by isolating parser-state carry-over, refined the documentation assessment to prioritize VT52/VT100 core compatibility over out-of-scope hardware-limited features, and replaced the former approximated DEC double-height handling with per-line top/bottom-half rendering semantics.
- Codebase changes: added comparison builds for Setup A/B ordering diagnostics, replaced the setup header's parsed `ESC c` with a direct renderer parser reset before drawing, moved DEC line attributes `ESC #3/#4/#5/#6` onto explicit per-row state instead of global font geometry switches, switched DEC double-height rendering to dedicated Circle `FontFlagsDoubleBoth` text and graphics generators and align the lower half to the visible glyph midpoint so `ESC #4` no longer drops the lower closure rows at the split, synchronized those attributes through scrolling and alternate-screen transitions, documented the VT100 conformance matrix plus a concrete `vttest` validation plan in `README.md`, and clarified accepted hardware scope limits for `DECCOLM`, `DECKPAM/DECKPNM`, and `DECCKM`.

## 2026-04-22
- Implemented features: GPIO overvoltage protection design finalized for Adapter Board revision V2.3; relay swap mismatch vulnerability identified and documented.
- Codebase changes: corrected Hardware.md — 1 kΩ only on RxD (not TxD); added relay scenario signal level analysis table; updated ToDo with null-modem vulnerability fix strategy (resistor before relay).
- Codebase changes: improved escape-sequence parsing for text attributes and continued fixes for combined attribute-command handling.

- Implemented features: added a setup-dialog diagnostic sample that renders DEC double-height top and bottom halves as separate test rows below the legacy footer text, corrected the VTTest ruler/header rows so they always render in normal size again, stopped stale DEC line attributes from leaking into subsequent test screens, reset VTTest full-screen transitions back to a clean whole-terminal baseline before each screen, shortened and centered the VTTest summary title for real double-width/double-height rendering, aligned the DECOM origin demo with the normal VTTest screen layout, made the Wrap ON/OFF tests switch the live renderer mode immediately before the boundary animation starts, converted the VTTest double-width/double-height demo blocks to explicit row-addressed DEC line-attribute sequences instead of relying on implicit CR/LF continuation, and changed the Summary DWDH title centering to use line-wide DEC height mode with text padding instead of mid-line `CUP` positioning.
- Codebase changes: updated `CTSetup::RenderHeader()` to render the setup title itself as a matching `ESC#3`/`ESC#4` pair, moved `TO EXIT PRESS "SET-UP"` directly below that title as on the real VT100 setup screen, removed the temporary header diagnostic test lines again, restored the lower-half renderer split to the true midpoint of the 44-pixel `DoubleBoth` glyph for direct comparison against the earlier diagnostics, refreshed VTTest comments plus README conformance notes so the documented `ESC#3/#4/#5` behavior now matches the confirmed renderer implementation, reset renderer line attributes inside `ClearDisplay()`, explicitly force the VTTest ruler rows back to `ESC#5` before drawing the numeric guides, changed both renderer `CSI 2J` full-screen clear paths to use the same complete line-attribute reset as `ClearDisplay()` so stale DEC line modes no longer survive VTTest summary clears, changed the summary DWDH title write to one centered explicit `ESC#3/#4/#5` sequence, changed the DECOM origin test sequence to reuse the normal frame instead of drawing a separate EXPECT/confirmation page, inserted a shared VTTest full-screen reset sequence that restores line size, charsets, origin mode, wrap mode, cursor visibility, scroll region, and then clears the whole display before intro/step/summary screens, changed the summary DWDH title rows to switch into `ESC#3/#4` at column 1 and center the text with leading spaces after clearing each line, capped the Summary DW/DWDH title width at 40 characters and replaced the unsupported precision-format truncation with direct character copying, call `SetWrapAroundMode()` directly from the Wrap ON/OFF test setup so the active renderer state matches the persisted config before boundary characters are emitted, and replaced the VTTest intro/title, summary title, graphics-font demo, and DEC line-attribute demo strings with explicit `ESC[row;colH` plus `ESC#3/#4/#5/#6` positioning so no DW/DWDH sample depends on implicit newline state anymore.

## 2026-01-22
- Implemented features: integrated `TFontConverter` and `TRenderer` into kernel runtime.
- Codebase changes: reworked kernel integration paths for renderer/font modules.

## 2026-02-23

- VT100 renderer: clamp `CUP` cursor moves to the visible grid so size-probing sequences like `ESC[999;999H` behave predictably (improves vttest layout on wide screens).
- VT100 renderer: implement missing erase variants `CSI 1J`, `CSI 1K`, and `CSI 2K` used by vttest.
- VT100 renderer: fix autowrap behavior to use a VT100-style wrap-pending state (prevents unintended extra newlines/scrolling when writing in the last column).
- VT100 renderer: implement DECAWM wrap mode toggles (`ESC[?7h`/`ESC[?7l`) and use runtime wrap-mode state (needed by vttest).
- Config: add `host_id` (IPv4[:port]) for shell-client mode; when set and `wlan_host_autostart=2`, the shell-client auto-connects without prompting for Host.
- Implemented features: stabilized WLAN shell-client sessions by keeping non-blocking receives from triggering false disconnects while still draining bursty output in a bounded loop.
- Codebase changes: updated `CTWlanHost::Tick()` to treat `Receive(..., MSG_DONTWAIT)==0` as idle/no-data (Circle TCP semantics) and only close on `NET_ERROR_CONNECTION_RESET` or real receive errors, added explicit close-reason logging, corrected `tools/start_raw_shell_server.sh` to exec the configured shell directly without an undefined `SCRIPT_BIN` path, extended the renderer CSI `ESC[?…h/l` parsing to consume/ignore bracketed paste mode (`?2004h/l`) so prompts no longer show a stray "4h", and added minimal vttest compatibility (C1 CSI 0x9B plus DA/DSR replies `ESC[c`, `ESC Z`, `ESC[5n`, `ESC[6n`) with non-blocking shell-client TX for responsive cursor keys plus cursor semantics fixes (DECOM origin mode `ESC[?6h/l`, CSI save/restore `ESC[s/u`, CUP `ESC[;colH`, and default scroll-region reset `ESC[r`); additionally, increased the shell-client TCP RX buffer to `FRAME_BUFFER_SIZE` to prevent Circle receive-chunk truncation from dropping bytes during burst output (e.g., vttest).

## 2026-01-29
- Implemented features: integrated `TUART` task flow for host TX/RX and renderer display path.
- Codebase changes: tuned task timing and debug behavior to improve runtime stability.

## 2026-01-30
- Implemented features: added HAL module capabilities (including buzzer/TxRx control), key-click support, and SD config-to-runtime mapping.
- Codebase changes: aligned configuration application across modules and identified/adjusted renderer color type mismatches.

## 2026-02-01
- Implemented features: progressed config integration tests (font/color selection) and documented refactoring state.
- Codebase changes: updated refactoring documentation and integration notes.

## 2026-02-02
- Implemented features: completed WLAN log integration with telnet client and restored expected keyboard auto-repeat behavior.
- Codebase changes: stabilized input/logging interaction paths.

## 2026-02-03
- Implemented features: enabled WLAN logging to file/screen/telnet and ensured startup configuration parameters are applied across modules.
- Codebase changes: finalized host-message display after telnet connection and documented known logging-screen redraw tradeoff.

## 2026-02-05
- Implemented features: improved Doxygen/header documentation workflow.
- Codebase changes: added/used documentation make targets and refreshed documentation structure.

## 2026-02-06
- Implemented features: added updated architectural documentation.
- Codebase changes: expanded architecture-level docs.

## 2026-02-07
- Implemented features: introduced initial Setup Screen A (F12), including display/context restore behavior.
- Codebase changes: migrated `TSetup` toward task implementation and documented remaining stability work for repeated activation.

## 2026-02-08
- Implemented features: completed Setup Dialog A with tab-stop configuration and ESC-based tab management commands.
- Codebase changes: persisted tab settings in `CTConfig` and connected setup UI behavior to config storage.

## 2026-02-09
- Implemented features: implemented underline and block cursor mode; added line-ending options (`LF`/`CR`/`CRLF`).
- Codebase changes: updated control-mode handling paths for cursor and EOL behavior.

## 2026-02-10
- Implemented features: added and executed ANSI/DEC escape-sequence test functions.
- Codebase changes: expanded test coverage for terminal control-sequence handling.

## 2026-02-11
- Implemented features: implemented broad ANSI/ESC coverage including insert/delete line tests, internal VT100 test updates, and graphics font-set selection groundwork.
- Codebase changes: refactored task-level synchronization with spinlock usage in kernel paths and updated architecture documentation.

## 2026-02-12
- Implemented features: implemented DEC extended graphics font-set switching, Setup B (partial), and TCP host access to VT100 terminal.
- Codebase changes: updated tests and README/documentation for terminal/network feature additions.

## 2026-02-13
- Implemented features: added additional file-based parameter configuration dialog and completed consolidation step after refactoring.
- Codebase changes: removed legacy app directory, consolidated documentation, added repository agent-instruction governance files, expanded governance policy with definition-of-done, validation escalation, commit-message draft standard, dependency/security impact reporting, added a commit-workflow exception to not request commits for DAILY_CHANGELOG-only changes, de-duplicated README section 6.2 by keeping the configuration table and merging missing option details into table notes, removed further README redundancies by keeping one authoritative WLAN host-mode workflow in section 9 and fixing documentation policy wording to a 4-document model, reduced overlap in Configuration_Guide/VT100_Architecture/Hardware by consolidating repeated command/key/status lists while preserving technical content, and added Hardware.md to README “Further Documentation” for better discoverability.

## 2026-02-14
- Implemented features: added non-blocking smooth-scroll animation with half-line intermediate frame timing for single-line scroll operations in the VT100 renderer.
- Codebase changes: extended `TRenderer` with smooth-scroll state/buffers and update-loop frame rendering, wired animation scheduling into `Scroll`/`InsertLines`/`DeleteLines` for count-1 paths, prevented immediate write-path flush during active animation, corrected RI behavior to trigger at scroll-region top, and connected Setup B group 1 bit 1 (leftmost, mask `0x8`) to persisted `smooth_scroll` config plus renderer runtime apply paths.
- Implemented features: updated the documentation set to match current smooth-scroll and Setup B behavior.
- Codebase changes: aligned README, Configuration Guide, Architecture, and Known Issues docs with current implementation status, including persisted `smooth_scroll` key coverage and SET-UP B group 1 leftmost bit mapping.

## 2026-05-02
- Implemented features: stabilized VTTest full-screen DEC transitions and summary-title rendering on hardware, then completed the monochrome SGR model for bold, dim, underline, and reverse with explicit off-codes and matching VTTest coverage, corrected setup dialog rendering so Setup A/B show the exit hint underlined in double-width mode, the modern setup title targets a real double-width row, setup redraws no longer trigger audible margin-bell tones, restored macOS compatibility for the host RAW shell helper's `--kill-existing` path, added editable `host_id` support to the modern setup dialog so shell-client targets are preserved and saved, and corrected cursor-movement semantics so `CUD/CUB` no longer scroll or wrap across lines during strict VT100 host tests.
- Codebase changes: added a shared VTTest full-screen reset baseline, normalized the DECOM demo and summary DWDH title logic, persisted the renderer dim attribute through save/restore and alternate-screen state, replaced the old SGR demo strings with monochrome intensity/reset sequences without adding ANSI color handling or blink changes, synchronized the README SGR status tables with the monochrome-only attribute subset, updated `CTSetup` to mute the renderer margin bell only while drawing setup screens, rewrote the modern title row to apply `ESC#6` on the actual title line before emitting centered padded text, added underline on the legacy `TO EXIT PRESS "SET-UP"` header line, replaced the Bash 4-only `mapfile` use in `start_raw_shell_server.sh` with a Bash 3.2-compatible PID collection loop, extended the modern setup state/value handling to edit and persist `host_id` into `VT100.txt`, and split scroll-capable VT100 index handling from non-scrolling cursor-step primitives in `CTRenderer` so `LF/IND/NEL` still scroll while `CSI B` and left-edge cursor moves clamp as expected.
- Implemented features: expanded VTTest coverage with dedicated smooth-scroll ON/OFF demo steps and an RI-at-scroll-top-margin validation scenario.
- Codebase changes: fixed VTTest step-name dispatch mismatches so ANSI/DEC prefixed step names trigger the intended sequence handlers, and restored smooth-scroll runtime state after VTTest execution.
- Implemented features: added a structured manual verification plan for features introduced since 2026-02-12 that are not fully covered by VTTest automation.
- Codebase changes: created `docs/Manual_Testplan_2026-02-12_to_2026-02-14.md` with step-by-step test cases and expected outcomes for WLAN host mode, setup persistence, and smooth-scroll runtime behavior.

## 2026-02-17
- Implemented features: restored visible smooth-scroll animation frames on Setup B toggle (frames now pushed each tick), unblocked macOS builds, refreshed Modern Setup with a three-column view (centered title, centered footer help), clarified serial defaults/baud range and color names, enabled bitmask log output selection (multiple sinks), preserved VT100.txt comments when saving, and added periodic scroll timing stats (smooth vs normal) logged every 30s.
- Codebase changes: push composed smooth-scroll frames to the framebuffer each animation tick, updated Config.mk to use the Homebrew-linked arm-none-eabi toolchain in /usr/local/bin, expanded Modern Setup layout with centered header/footer and Description column, refined Modern descriptions, changed log output editing to toggle sink bits (screen/file/WLAN), added save logic to merge updated values into existing VT100.txt without stripping comments using Circle `CString`-compatible formatting/appends, slowed smooth-scroll pacing to ~170ms per line (~6 lps) with per-pixel steps, ensured smooth-scroll frames render live buffer content so new lines appear progressively instead of in a final batch, replaced scroll queueing with a debounce guard so isolated single-line scrolls animate while bursts fall back to instant (eliminating multi-line jumps/backtracks), and instrumented scroll paths to record/emit per-mode durations; verified a clean `make -j4` build in VT100.
- Implemented features: setup dialogs A, B, and Modern now honor the actively configured VT100 font family instead of forcing 10x20 CRT, and the Modern setup title is rendered single-line and centered correctly.

## 2026-04-30
- Implemented features: stabilized legacy setup rendering so F11 opens the modern dialog directly, Setup A/B restore their content reliably, and the Setup B header no longer depends on the renderer's broken DEC bottom-half double-height handling.
- Codebase changes: refactored `CTSetup` show paths to separate legacy and modern dialog activation, added renderer-state normalization before setup redraws, corrected legacy header handling after `ESC#4` regression, restored stable Setup A/B title positioning by using `ESC#3` only and resetting to normal font before later row-based rendering, added a VT100 `RIS` reset before each legacy header draw so Setup B no longer inherits parser/terminal state from the Setup A page switch, aligned Setup B's bottom settings row with Setup A while removing a stray debug `!`, made the subtitle row offset configurable for Setup B, and added a targeted bottom-scanline clear when rendering the higher Setup B title to counter the observed top-to-bottom pixel wrap artifact; verified with `make -j4` in VT100.
- Codebase changes: switched renderer ESC #3/#5/#6 font-mode handling to reuse the current configured font selection, changed startup config font application to use selection-based API so state restoration keeps selection metadata, and removed double-width title rendering in Modern setup while centering title text against the inner content width.
- Implemented features: Modern setup title now renders in double width and remains centered.
- Codebase changes: updated Modern title centering math to account for double-width rendered text (`ESC#6`) and restored DEC normal-width reset (`ESC#5`) after title draw.
- Implemented features: corrected Modern setup title placement so double-width title is truly centered instead of drifting to the right.
- Codebase changes: switched title placement to double-width coordinate centering by entering `ESC#6` before `Goto` and calculating the start column in double-width columns for the inner dialog area.
- Implemented features: moved Setup B dialog content block one normal-height line higher to remove the lower-edge placement glitch.
- Codebase changes: shifted Setup B info/data rows and field cursor row from the last screen line pair to the pair above (`rows-3`/`rows-2`) while preserving existing field/bit positions.
- Implemented features: ensured Setup A to Setup B page transitions start from a fully normalized text/font state.
- Codebase changes: added explicit header preamble reset in setup legacy rendering (`ESC[0m`, `ESC(B`, `ESC)B`, `SI`, `ESC#5`) before drawing titles/subtitle so lingering attributes/charset/font-width modes cannot leak between setup pages.
- Implemented features: synchronized user/developer markdown documentation with current implementation status for setup dialogs and serial flow control.
- Codebase changes: updated README and docs to mark SET-UP B Auto XON/XOFF as implemented (`flow_control`), documented persisted `flow_control` key, corrected Modern setup layout description to centered double-width title plus parameter/value/description columns, and captured legacy setup A/B header state normalization behavior.
- Implemented features: implemented legacy SET-UP B margin bell behavior (group 2 leftmost bit) to ring when the cursor reaches 8 characters before the right margin.
- Codebase changes: added persisted `margin_bell` config key, mapped SET-UP B group 2 leftmost toggle to `margin_bell`, and added renderer runtime trigger to call buzzer bell at column `right_margin - 8` for printable character output when enabled.

## 2026-02-18
- Implemented features: added an interactive VTTest step to verify margin bell behavior by starting 5 characters before the bell margin, writing past the threshold, and asking the user to confirm whether the bell sounded.
- Codebase changes: extended `VTTest` core steps with `Margin Bell Right-8`, added dedicated run-path logic to enable margin bell for the test, position the cursor at `right_margin - 13`, write a character burst across the bell point, and keep PASS/FAIL capture integrated into the existing summary output.
- Implemented features: implemented SET-UP B wrap-around control (group 3, second bit from left) with VT100-compatible semantics for both modes, plus two interactive verification tests for wrap ON and wrap OFF behavior with summary reporting.
- Codebase changes: added persisted `wrap_around` config key (default on), mapped SET-UP B group 3 bit mask `0x4` to `wrap_around`, updated renderer printable-character advance logic to hold/overwrite at right margin when wrap is off, and extended VTTest with `Wrap Around ON` and `Wrap Around OFF` steps while preserving/restoring wrap setting across test runs.
- Implemented features: added a keyboard local mode toggle on `F10` that switches input to local loopback and shows an on-screen status line when activated.
- Codebase changes: added `CKernel` local-mode state/toggle handlers, wired `F10` raw-key edge detection into the periodic dispatch path, and routed keypress output to `TRenderer::Write` instead of host/UART while local mode is enabled.
- Implemented features: stabilized runtime responsiveness after introducing local-mode key toggles by preventing periodic input-dispatch starvation under repeated function-key reports.
- Codebase changes: changed periodic `F10`/`F11`/`F12` dispatch in `kernel.cpp` from unbounded queue-drain loops to bounded single-event-per-tick handling so scheduler/yield cadence remains intact and serial/keyboard/setup processing continues.
- Implemented features: synchronized all markdown documentation (`README.md` and every file in `docs/`) with current implemented runtime behavior for local mode, margin bell, and wrap-around.
- Codebase changes: corrected SET-UP B mapping tables (`margin_bell` and `wrap_around`), added `F10` local-mode user/developer flow notes, expanded manual verification guidance, and refreshed known-issues/refactoring/hardware notes for current firmware behavior.
- Implemented features: aligned the shipped `VT100/bin/VT100.txt` template with the active firmware key set and defaults.
- Codebase changes: added missing keys (`smooth_scroll`, `wrap_around`, `flow_control`, `margin_bell`), corrected default values (`vt_test=0`, `log_output=0`), and fixed buzzer range documentation to `0..100`.
- Implemented features: restructured the manual verification plan into standardized test-case blocks with explicit pass criteria and result reporting.
- Codebase changes: updated `docs/Manual_Testplan_2026-02-12_to_2026-02-14.md` to include a TOC, per-test title/purpose sections, step tables (`Step No`, `Description`, `Expected Result`, `Verification`), a global rule that all steps must pass, and a consolidated summary results table.
- Implemented features: restored Modern Setup dialog close/save behavior on Enter across keyboard variants that emit CR/LF combinations.
- Codebase changes: updated `CTSetup::HandleModernKeyPress` to treat `\r`, `\n`, `\r\n`, and `\n\r` as valid Enter input sequences that set save+exit flags.
- Implemented features: Modern Setup now applies changed font selection immediately when closing with Enter (Save).
- Codebase changes: extended setup post-save runtime apply in `CTSetup::Run` to call `TRenderer::SetFont(config->GetFontSelection(), FontFlagsNone)` alongside existing color/cursor/VT mode updates.
- Implemented features: expanded Modern Setup save-apply behavior so additional settings now take effect immediately across runtime subsystems.
- Codebase changes: added `CKernel::ApplyRuntimeConfig()` and wired setup save through it, applying renderer visual state, HAL buzzer/RxTx swap, keyboard repeat timing refresh, UART re-initialization from config, and log target reconfiguration (screen/file/WLAN) without reboot.
- Implemented features: added explicit field-by-field verification guidance for Modern Setup runtime apply behavior.
- Codebase changes: updated `docs/Configuration_Guide.md`, `README.md`, and `docs/Manual_Testplan_2026-02-12_to_2026-02-14.md` with a runtime-apply matrix, subsystem mapping notes, and a dedicated manual test section (`C4`) covering immediate-apply expectations.
- Implemented features: restored stable repeated use of F11/F12 setup dialogs after runtime-apply integration regression.
- Codebase changes: narrowed `CKernel::ApplyRuntimeConfig()` to safe non-disruptive runtime updates (renderer/HAL) and removed keyboard/UART/logging live reconfiguration from dialog-close path to avoid callback-state corruption; documentation runtime-apply matrix was aligned accordingly.
- Implemented features: reduced visible flicker in the F11 Modern setup dialog by updating only affected content rows on selection/value changes instead of repainting the full dialog each keypress.
- Codebase changes: refactored `CTSetup` modern rendering into layout-aware row/list rendering helpers with cached dialog geometry, changed arrow-key handling to perform partial dirty-row updates with safe fallback to full redraw on geometry/window shifts, and reset cached layout state on dialog mode transitions.
- Implemented features: restored keyboard input after closing VTTest summary with Return so terminal typing resumes immediately at home position.
- Codebase changes: gated `CKernel::HandleVTTestKey` forwarding on active `vt_test` config state and hardened `CVTTest::Stop()` to clear summary/wait/pending/sequence hold flags, preventing stale test-state key capture after exit.
- Implemented features: fixed VTTest skip path (test flag on + SPACE skip) so keyboard/serial input resumes immediately after returning to cursor position 1,1.
- Codebase changes: switched VTTest key interception in `CKernel` to runtime-active gating (`CVTTest::IsActive()`), and made `CVTTest::Stop()` always clear `vt_test` state before renderer-dependent cleanup to prevent lingering interception after skip/summary exit.
- Implemented features: refined VTTest suite structure by merging DEC tests 2+3, naming DEC test 4 explicitly, removing unsupported DEC test 5, and converting tests 36/37/38 to animated character-by-character demonstrations.
- Codebase changes: updated `VTTest` step tables (DEC suite + titles), removed `DEC Screen Test`, and changed Wrap ON/OFF + Margin Bell runtime paths to staged sequence playback with visible incremental character updates from a defined start state.
- Implemented features: resolved remaining VTTest exit lockup so both skip-from-intro and exit-after-summary reliably return to normal keyboard/serial operation.
- Codebase changes: replaced callback-context VTTest stop/clear calls with deferred stop requests handled in `CVTTest::Tick()`, ensuring renderer clear/home and `Stop()` run in task context and preventing post-test input deadlock.
- Implemented features: improved VTTest cases 33/34/35 to show real line-end and bell-margin behavior on wider screens with visible markers and dynamic character injection at ~5 chars/sec.
- Codebase changes: replaced fixed-column wrap/margin test scripts with runtime-generated boundary animations based on current renderer dimensions, added explicit end-of-line/next-line and bell-margin markers, and triggered audible bell explicitly via `CHAL::Get()->BEEP()` when the animated stream crosses the bell margin.
- Implemented features: restored rendering of embedded PNG figures in Markdown-based Doxygen pages.
- Codebase changes: configured `IMAGE_PATH` in `VT100/Doxyfile` to include `docs/images` and normalized Markdown embedded image `src` paths in `README.md` and `docs/Hardware.md` to emitted filenames so Doxygen resolves and renders copied PNG/JPEG assets reliably.
- Implemented features: added a build-reference section listing all implemented Make targets and their usage purpose directly in the compile environment chapter.
- Codebase changes: inserted a `Make Targets` table in `README.md` below `Compile Environment Setup`, covering project-local targets (`all`, `kernel.img`, `docs`, `docs_clean`) plus inherited Circle `Rules.mk` targets (`clean`, `install`, `tftpboot`, `flash`, `monitor`, `cat`).
- Implemented features: added explicit toolchain maintenance Make targets for one-command Circle toolchain configuration and compiler/header verification.
- Codebase changes: extended `VT100/Makefile` with `toolchain-configure` (wraps `third_party/circle/configure -f -p <prefix>`) and `toolchain-check` defaults (`TOOLCHAIN_PREFIX`, `CHECK_TMPDIR`) to support stable checks even when system temp is constrained.
- Implemented features: restored working README image embedding and documentation links after moving project README to repository root.
- Codebase changes: updated root `README.md` relative paths for embedded images to `VT100/docs/images/...` and developer guide links to `VT100/docs/...` so GitHub rendering resolves correctly from the new location.
- Implemented features: enabled automatic publishing of generated Doxygen HTML documentation to GitHub Pages on each push to `main`.
- Codebase changes: added repository-level GitHub Actions workflow `.github/workflows/docs-pages.yml` to install Doxygen/Graphviz, run `make docs` in `VT100/`, and deploy `VT100/docs/doxygen/html` via Pages; added root `README.md` link to the published Pages documentation URL; updated `VT100/Doxyfile` input/mainpage from `README.md` to `../README.md` after moving the project README to repository root.
- Implemented features: stabilized GitHub Pages docs deployment by ensuring CI checks out required project submodules.
- Codebase changes: updated `.github/workflows/docs-pages.yml` checkout step to `submodules: recursive` so `third_party/circle/Rules.mk` is available during `make docs` in CI.
- Implemented features: restored image rendering for root-README content on the generated Doxygen main page.
- Codebase changes: extended `VT100/Makefile` `docs` target to mirror `VT100/docs/images` into `VT100/docs/doxygen/html/VT100/docs/images`, matching root-README image paths (`VT100/docs/images/...`) used by Doxygen when `../README.md` is the main page.
- Implemented features: restored Mermaid diagram rendering in Git-hosted Markdown views for architecture documentation.
- Codebase changes: added standard fenced `mermaid` code blocks to `VT100/docs/VT100_Architecture.md` for the dependency graph and sequence diagrams, while preserving existing Doxygen `\htmlonly` Mermaid blocks for generated HTML docs.
- Implemented features: removed duplicate architecture diagram output in Git Markdown views.
- Codebase changes: removed legacy Doxygen-only `\htmlonly` Mermaid blocks from `VT100/docs/VT100_Architecture.md`, leaving a single canonical set of fenced `mermaid` diagrams to avoid rendered+text duplication in Git.

## 2026-02-19
- Implemented features: restored visible images in the hardware description markdown page.
- Codebase changes: updated `VT100/docs/Hardware.md` image references from local-file names to `images/...` paths (`Schematic_V22.png`, `Layout_V22.png`, `Backplate_Front.png`, `Backplate_Back.png`) so Git Markdown and Doxygen resolve the assets from `VT100/docs/images` correctly.
- Implemented features: improved telnet host-mode recoverability by adding a firmware-side fallback escape sequence for returning to command mode when client-side `Ctrl-]` handling is unavailable.
- Codebase changes: extended `CTWlanLog` host-mode RX handling to recognize `+++` as a host-mode exit trigger, updated host-mode help/session prompts to advertise both `Ctrl-]` and `+++`, and synchronized operator/developer guidance in `docs/Configuration_Guide.md`.
- Implemented features: added on-screen telnet connect guidance to the waiting state so users can see the target endpoint directly on VT100 while waiting for a remote session.
- Codebase changes: updated `CKernel::MarkTelnetWaiting()` to render a dynamic waiting message with `telnet <ip> 2323` when IP is available, and a `<ip-address>` placeholder plus port fallback when IP is not yet assigned.
- Implemented features: introduced a consistent command-mode telnet prompt (`>: `) and updated host-mode escape controls to use `Ctrl-C` with `+++` as fallback.
- Codebase changes: added command-prompt emission in `CTWlanLog` for command mode (session start, after entered lines, and after host-mode exit), removed `host off` from command interface/help text, switched host escape handling from `Ctrl-]` to `Ctrl-C`, and synchronized `docs/Configuration_Guide.md` accordingly.
- Implemented features: extended the VT100 telnet waiting screen to also show a hostname-based `.local` connect hint in addition to the IP/port hint.
- Codebase changes: updated `CKernel::MarkTelnetWaiting()` to append `telnet <hostname>.local 2323` when hostname is available, and documented the dual waiting-screen connect hints in `docs/Configuration_Guide.md`.
- Implemented features: improved command-mode telnet usability by making log output prompt-safe and normalizing empty-line Enter handling.
- Codebase changes: updated `CTWlanLog` to track prompt visibility, force asynchronous log output onto a fresh line before restoring the `>: ` prompt in command mode, and emit `\r\n` plus prompt on empty Enter so Return no longer appears as `^M`; documentation was aligned in `docs/Configuration_Guide.md`.
- Implemented features: waiting-screen telnet connect hint now upgrades from placeholder to real IP automatically once DHCP address assignment completes.
- Codebase changes: added kernel-side waiting-message IP-state tracking and periodic waiting-screen refresh trigger while no telnet client is connected, so `MarkTelnetWaiting()` re-renders once concrete IP data becomes available instead of staying on `<ip-address>`.
- Implemented features: fixed command-mode telnet output layout so command responses no longer appear inline with Enter as `^M` artifacts.
- Codebase changes: adjusted `CTWlanLog::HandleCommandChar()` to emit a clean CRLF before processing non-empty command lines, ensuring `help`/`status` output starts on a new line while preserving existing `echo` behavior.
- Implemented features: waiting/connect guidance on VT100 is now shown only once a real IP address is available, avoiding duplicate early/late waiting messages.
- Codebase changes: updated `CKernel::MarkTelnetWaiting()` to defer rendering until DHCP yields a concrete IP and to skip placeholder rendering while still keeping telnet-wait state active.
- Implemented features: improved telnet command-mode input rendering by enabling server-side echo negotiation and firmware echo of typed command characters/backspace handling.
- Codebase changes: switched telnet negotiation to `WILL ECHO`, accepted `DO ECHO`, and added command-mode character/backspace echo sequences in `CTWlanLog::HandleCommandChar()` to reduce client-side `^M` artifacts.
- Implemented features: normalized telnet logger line endings in both command and host mode so log messages render with proper CRLF boundaries.
- Codebase changes: reworked `CTWlanLog::Write()` to normalize `\n` to `\r\n` (with split-write-safe CR tracking), preserve command-mode prompt behavior with line-safe prompt restoration, and reset CR-tracking state on connection reset.
- Implemented features: restored reliable `exit` behavior in telnet command mode by preventing close-path lock recursion.
- Codebase changes: refactored `CTWlanLog::CloseClient()` to defer disconnect logger writes until after send-lock release, removing a potential deadlock when logger output re-enters the telnet write path during disconnect.
- Implemented features: improved telnet disconnect UX by restoring stable telnet input negotiation and adding an explicit VT100 on-screen disconnect notice.
- Codebase changes: reverted command-side telnet echo negotiation/character-injection changes (`WILL ECHO` path) back to the prior negotiation mode, and added a renderer-side `Telnet client disconnected` message in `CTWlanLog::CloseClient()` before returning to waiting state.
- Implemented features: stabilized `exit` disconnect handling by deferring socket close to a safe point after receive-chunk processing.
- Codebase changes: changed `exit` command flow to set a deferred close flag processed in `HandleIncomingData()`, prevented further byte handling once close is requested, and replaced hardcoded disconnect text length with dynamically sized reason-aware VT100 disconnect messages.
- Implemented features: reduced command-mode telnet `^M` artifacts by enabling server-side ECHO negotiation.

## 2026-04-30
- Implemented features: stabilized setup dialog activation and rendering for mini-keyboard F11/F12 usage, including direct Modern dialog entry and cleaner legacy title redraw.
- Codebase changes: refactored `CTSetup` to prepare dialog state without forcing an intermediate SET-UP A render, added explicit renderer state normalization before setup draws, and fixed legacy double-height header rendering to redraw the title on both title rows.
- Codebase changes: updated telnet option negotiation in `CTWlanLog` to advertise `WILL ECHO` and accept `DO ECHO` alongside suppress-go-ahead handling, while keeping deferred-close disconnect logic unchanged.
- Implemented features: added a post-greeting telnet notice indicating WLAN mode is active and network establishment may require waiting before connection-ready messages appear.
- Codebase changes: extended `CTWlanLog::AnnounceConnection()` greeting text with an explicit wait hint for WLAN/network setup progress.
- Implemented features: fixed the `VT100_TTY` helper script so `screen` is attached directly to the PTY bridge, enabling bidirectional host-mode loop testing.

## 2026-02-24
- Implemented features: improved VT100/vttest compatibility by adding a robust CSI parser (multi-parameter SGR), implementing RIS and DECALN, and making insert-mode semantics effective.
- Codebase changes: replaced the legacy two-parameter CSI state machine with a parameter-list CSI parser, fixed DSR cursor-position reports under origin mode (DECOM) so cursor-movement tests behave correctly, added ICH (`CSI @`) and IRM shifting on printable output, and validated with `make -j4` in `VT100/`.
- Codebase changes: replaced one-way `tee` usage with direct `screen <pty>` attachment, changed default TCP port to `2323`, and added robust startup/cleanup handling (`set -euo pipefail`, trap-based process/file cleanup, PTY readiness wait loop).
- Implemented features: extended `VT100_PTY` with optional automatic line reply mode for host-loop testing (`--autorespond`).
- Codebase changes: added argument parsing/help output, screen logfile-based responder process with `AUTO:` loop-prevention tagging, and cleanup handling for responder/log artifacts while keeping default interactive behavior unchanged.
- Implemented features: restored `VT100_PTY --autorespond` startup compatibility on macOS by removing unsupported `screen` logfile option usage.
- Codebase changes: removed leftover `screen -Logfile` invocation, switched autorespond logging to a dedicated temp directory with `screen -L` (`screenlog.0`), and verified script startup no longer fails with `Unknown option Logfile`.
- Implemented features: improved `VT100_PTY --autorespond` runtime stability for host-mode loop testing on macOS.
- Codebase changes: removed `socat` PTY escape termination (`escape=0x03`) to avoid unintended bridge shutdown on control-byte traffic, normalized autoresponder log parsing for CR/LF streams, and fixed macOS locale-related `tr: Illegal byte sequence` failures via `LC_ALL=C` in the log-tail pipeline.
- Implemented features: simplified autorespond flow by keeping `socat` + `screen` and running a dedicated Python echo helper inside the `screen` session.
- Codebase changes: refactored `VT100_PTY --autorespond` to launch `screen` with `VT100_SCREEN_ECHO.py` (`--pty` bridge path, `AUTO:` prefix), removed logfile-tail based responder logic, and deleted obsolete standalone helper `VT100_TCP_ECHO.py`.
- Implemented features: aligned host-mode loop testing with a minimal stdin/stdout responder path and reduced multi-echo artifacts in host mode.
- Codebase changes: changed `VT100_PTY --autorespond` to execute `VT100_SCREEN_ECHO.py` as a pure stdin->stdout helper via PTY redirection (`< "$PTY" > "$PTY"`) inside `screen`, simplified `VT100_SCREEN_ECHO.py` to byte passthrough only, and updated `CTWlanLog::Write()` to suppress logger mirroring to the remote client while host mode is active so PTY loopback traffic is not amplified by log lines.
- Implemented features: stabilized `--autorespond` startup when launched under `screen` on environments with reduced shell `PATH`.
- Codebase changes: added Python interpreter resolution (`python3`/`python`) in `VT100_PTY` and switched screen command execution to use the resolved absolute interpreter path so autoresponder no longer exits with `python3: command not found`.
- Implemented features: made simulated host responses visually identifiable in host-mode loop tests.
- Codebase changes: updated `VT100_SCREEN_ECHO.py` to echo complete lines with `SIMHOST: ` prefix and added loop protection to skip lines already marked as simulated-host output.
- Implemented features: improved simulated host interaction control by preventing startup-message re-echo, forwarding Ctrl-C escape to VT100 host mode, and performing graceful shutdown signaling.
- Codebase changes: extended `VT100_SCREEN_ECHO.py` with filtered ignore prefixes for known WLAN/telnet greeting/log lines, `SIGINT` handling that forwards `0x03` (host-mode exit), and shutdown sequence forwarding (`Ctrl-C` + `exit`) on EOF/termination.
- Implemented features: enforced silent remote-session startup when WLAN host auto-start is enabled so host mode begins without sending greeting/status text to the remote endpoint.
- Codebase changes: updated `CTWlanLog::AcceptClient()` to detect auto-host mode before connection announcement, skip remote welcome/help/status `SendLine` traffic in that mode, enable host mode immediately on connect, and keep connection/auto-start notices local via logger fallback only.
- Implemented features: improved host-mode exit robustness with deterministic Ctrl-C shutdown signaling and stable local VT100 recovery after telnet disconnects.
- Codebase changes: updated `VT100_SCREEN_ECHO.py` to treat Ctrl-C as immediate graceful shutdown (`Ctrl-C` + `exit`), ignore non-printable/noisy lines before simulated-host echoing, changed `CTWlanLog::CloseClient()` to resume local-ready state for client-side close reasons (`requested by client`, `receive failed`, `send failed`), and adjusted kernel telnet-waiting transitions to avoid forcing immediate waiting-mode re-entry while local-ready mode is active.
- Implemented features: removed residual startup control-character injection and improved first-line responder handling for CR-terminated input.
- Codebase changes: changed `VT100_SCREEN_ECHO.py` shutdown sequence to `exit\r` (no injected `Ctrl-C`), stopped sending shutdown bytes on plain EOF, and replaced LF-only line splitting with CR/LF-aware delimiter parsing so early host input is processed as soon as `CR` or `LF` arrives.
- Implemented features: suppressed stray startup control-character artifacts (`^C^CA`) at host-mode entry before first real remote payload.
- Codebase changes: added host-data priming state in `CTWlanLog` and updated host-mode RX handling to drop early non-printable control bytes until first printable/escape payload arrives, while preserving normal host rendering once primed.
- Implemented features: removed telnet-option byte leakage in auto-host raw sessions by disabling telnet negotiation for auto-start host mode.
- Codebase changes: updated `CTWlanLog::AcceptClient()` to skip `SendTelnetNegotiation()` when `wlan_host_autostart` is enabled, keeping raw `socat/screen` host-loop sessions free of telnet control-sequence artifacts (`^C^CA`) while retaining telnet negotiation for non-auto-host command sessions.
- Implemented features: restored sane line alignment for host full-screen tools (e.g. `top`) by supporting ANSI New Line Mode (LNM).
- Codebase changes: added renderer-side LNM state and implemented `CSI 20h/20l` so incoming `LF` can be interpreted as either IND or CR+IND, defaulting to CR+IND for compatibility.
- Implemented features: improved `top`/curses rendering under `TERM=xterm-256color` by supporting xterm alternate-screen mode.
- Codebase changes: implemented `CSI ?47/?1047/?1049 h/l` alternate screen snapshot/restore in the renderer so full-screen apps can use a clean buffer without corrupting the normal screen.
- Implemented features: added an internal VTTest geometry marker screen to diagnose top-row cropping/overlap.
- Codebase changes: extended `VTTest` with a "VT100 Geometry Markers" step (row/col/corner labels) and a DECALN fill step (`ESC # 8`) for quick visual validation.
- Implemented features: improved VTTest geometry-marker usability by showing centered expected-result instructions with explicit PASS/FAIL keys.
- Codebase changes: updated the "VT100 Geometry Markers" VTTest step to render centered guidance text (`RETURN = OK` / `SPACE = NOT OK`) based on runtime rows/cols.
- Implemented features: clarified geometry-marker diagnostics by isolating the top/bottom rows to corner-only markers and moving row labels to start at ROW03.
- Codebase changes: adjusted the geometry-marker layout so row 1 and the last row contain only corner markers, row 2 contains only the column ruler, and left-edge row labels start at row 3.
- Implemented features: added a VTTest check to validate DEC Origin Mode (DECOM) cursor positioning relative to a scroll region.
- Codebase changes: added a "DECOM Origin + Scroll Region" VTTest step that places markers using CUP under `ESC[?6h/l` to verify absolute vs margin-relative addressing.
- Implemented features: improved DECOM VTTest usability by animating the origin-mode phases and reusing the scroll-region line-stream demo.
- Codebase changes: refactored the DECOM VTTest step into a timed multi-part sequence followed by the existing L1..L10 scroll animation, with automatic DECOM/scroll-region reset after completion.

## 2026-02-20
- Implemented features: enforced strict WLAN log-mode vs host-mode session separation without transitional/manual in-session host switching.
- Codebase changes: removed manual `host on` command path and host escape fallback switching from `CTWlanLog`, made host-mode input path raw per session, aligned README/configuration/architecture/test plan/separation-plan docs to strict-only semantics, and validated with `make -j4` plus `make docs`.
- Implemented features: completed documentation harmonization for the transition from multiplexed WLAN operation toward clean log-mode vs host-mode separation, including a dedicated phased separation roadmap.
- Codebase changes: added root `.gitignore` cleanup rules for local/generated artifacts, updated `README.md`, `docs/Configuration_Guide.md`, `docs/VT100_Architecture.md`, and `docs/Manual_Testplan_2026-02-12_to_2026-02-14.md` to align terminology and workflows (`log mode`, transitional `host on`, `Ctrl-C`/`+++` exit), and created `docs/WLAN_Mode_Separation_Plan.md` with phased implementation, config migration (`wlan_mode_policy` proposal), and validation strategy.
- Implemented features: added explicit execution status tracking in the WLAN separation plan to show completed vs open phases.
- Codebase changes: updated `docs/WLAN_Mode_Separation_Plan.md` with a dated current-status section and phase markers (`DONE`/`OPEN`) reflecting the implemented strict-separation state.
- Implemented features: added explicit 3-state WLAN mode policy and user-facing mode/status messaging for WLAN log, WLAN host, and WLAN disabled operation.
- Codebase changes: changed `wlan_host_autostart` handling to `0=off`, `1=log`, `2=host` across config parsing, setup mapping, and runtime activation logic; added post-greeting WLAN mode info after config load; merged connect hints into one line (`IP` + `hostname.local`); changed client connect notices to mode-specific wording; and adjusted WLAN log-mode prompt/log formatting to separate log output from prompt with spaces only (no extra CRLF before log messages).
- Implemented features: completed VT100 template coverage for persisted setup/config parameters, including the missing SET-UP B related options.
- Codebase changes: updated `VT100/templates/VT100.txt` and `VT100/bin/VT100.txt` to include `flow_control`, `smooth_scroll`, `wrap_around`, and `margin_bell`, and aligned shipped template defaults (`vt_test=0`, `log_output=0`) with firmware defaults.
- Implemented features: restored visible command entry in WLAN log-mode telnet sessions so typed characters are shown while commands are entered.
- Codebase changes: updated `CTWlanLog::HandleCommandChar()` to echo printable characters immediately to the telnet client and to render backspace/delete as `\b \b` when editing the command line, while preserving existing command execution and VT100 display routing behavior.
- Implemented features: improved host-mode disconnect UX with a dedicated local VT100 status message on session end.
- Codebase changes: updated `CTWlanLog::CloseClient()` to show `Host disconnected - resume normal operation` after host-mode disconnect while keeping non-host disconnect messaging unchanged.
- Implemented features: refined host-mode on-screen status texts for waiting and session connect states.
- Codebase changes: updated `CKernel::MarkTelnetWaiting()` to show `Waiting for host to connect via tcp ...` in host mode, and `CKernel::MarkTelnetReady()` to show `Host connected via tcp - CRTL-C in host session to close connection` on host connect.
- Implemented features: documented successful local loopback verification for WLAN logging mode and WLAN host mode in the main project README.
- Implemented features: enabled launching arbitrary interactive programs through the PTY bridge helper to support VT100 emulation tests with tools like `vttest` inside `screen`.
- Codebase changes: extended `VT100/tools/host_loopback/VT100_PTY` with robust optional server/port parsing, new `--run command [args...]` mode, updated help text/examples, and argument validation to prevent invalid `--autorespond` + `--run` combinations.
- Implemented features: fixed `--run` execution for TTY-dependent interactive tools (including `vttest`) so they can run correctly inside `screen` via the PTY bridge.
- Codebase changes: changed `VT100/tools/host_loopback/VT100_PTY` `--run` path to launch commands via `script -q /dev/null -c ...` (controlling TTY), added explicit `script(1)` dependency check/error message, and updated help text with the TTY behavior note.
- Implemented features: restored `--run` compatibility on macOS/BSD environments where `script` does not support `-c` and where `screen` subshell PATH may not include `script`.
- Codebase changes: updated `VT100/tools/host_loopback/VT100_PTY` to detect `script` variant (`-c` support), use BSD-style invocation when required, resolve `script` to an absolute executable path (including `/usr/bin/script` fallback), and execute that resolved path inside `screen`.
- Codebase changes: updated `README.md` networking/feature sections to explicitly state successful validation with `VT100_PTY --autorespond`.
- Implemented features: aligned host-mode README workflow with the real `VT100_PTY --autorespond` helper behavior and documented the recommended host-loopback tooling placement.
- Codebase changes: replaced manual-only host bridge instructions with helper-first workflow details (`SIMHOST:` responder semantics, filtering, clean shutdown), added placement guidance for `VT100/tools/host_loopback/`, and corrected `VT100_PTY` help text from `AUTO:` to `SIMHOST:`.
- Implemented features: consolidated WLAN mode-separation architecture into the main architecture reference and retired the standalone separation-plan document.
- Codebase changes: integrated strict session model, data-path gates, telnet negotiation policy, and connect/close lifecycle semantics into `docs/VT100_Architecture.md` section 8.3, updated references in `README.md` and `docs/Configuration_Guide.md`, and deleted `docs/WLAN_Mode_Separation_Plan.md`.
- Implemented features: relocated host-loopback helper tooling into the VT100 tools tree while preserving existing root command usage.
- Codebase changes: moved `VT100_PTY` and `VT100_SCREEN_ECHO.py` to `VT100/tools/host_loopback/`, replaced root `VT100_PTY` with a compatibility launcher delegating to the new path, and removed the legacy root `VT100_SCREEN_ECHO.py` copy.
- Implemented features: updated release handoff guidance with explicit SD deployment instructions and sanitized WLAN template credentials.
- Codebase changes: edited release `v0.9.0` notes to require copying the complete `VT100/bin` directory to SD and adapting `wpa_supplicant.conf`, and anonymized `VT100/bin/wpa_supplicant.conf` placeholders for `ssid`/`psk`.
- Implemented features: prepared English-language outreach text packages for retro-computing community channels.
- Codebase changes: created local `PR/` text templates (Hackaday project, Reddit variants, tipline, short social) and added `PR/` to root `.gitignore` so drafting materials stay local and are not published to GitHub.

## 2026-02-21
- Implemented features: approved and documented the WLAN target operating model as exactly two modes (`Remote Logging/Status` and `Remote Shell Client`) with host-server legacy removed from the final target architecture.
- Codebase changes: updated `docs/Configuration_Guide.md`, `docs/VT100_Architecture.md`, and `README.md` with target-mode definitions, migration mapping from `wlan_host_autostart`, phased implementation order, and aligned current-state vs target-state terminology.
- Implemented features: aligned runtime/operator-visible WLAN mode behavior wording to the target model so mode `2` is communicated as `Shell Client` instead of legacy host naming in setup/config/logging paths.
- Codebase changes: updated mode descriptions and status/help/waiting/connection messages across `include/TConfig.h`, `src/TConfig.cpp`, `src/TSetup.cpp`, `src/kernel.cpp`, `include/kernel.h`, `include/TWlanLog.h`, and `src/TWlanLog.cpp` while keeping existing APIs and numeric mode mapping intact.
- Implemented features: changed mode `wlan_host_autostart=2` behavior from legacy inbound `:2323` wait path to interactive shell-client setup input on VT100 (host/user/password capture in RAM only).
- Codebase changes: updated `src/kernel.cpp` keyboard routing and runtime mode activation to disable telnet listener startup in mode `2`, added interactive prompt state machine and masked password entry, and added explicit runtime notice that SSH client transport is not yet implemented.
- Implemented features: added outbound shell-client TCP bridging path (keyboard uplink + renderer downlink) with interactive target input usage, plus automatic SSH endpoint detection and safe-close messaging.
- Codebase changes: extended `CKernel` with shell-client connection lifecycle (`Connect/Send/Receive/Close`), IPv4 host parsing with optional `:port`, reconnect backoff to avoid busy-loop retries, and mode-2 exclusive routing that bypasses UART fallback while shell-client mode is active.
- Implemented features: added a robust host-side RAW shell server launcher for `shell_client` operation, including parameterized port/shell selection and controlling-TTY-safe startup behavior.
- Codebase changes: created `tools/start_raw_shell_server.sh` with argument/help validation, `script(1)` compatibility detection, optional existing-listener cleanup, and stable `socat` PTY options; expanded `tools/README.md` with dedicated usage and troubleshooting notes for RAW shell sessions.
- Implemented features: improved RAW shell session reliability for control-key and single-character interactive applications by applying terminal-sane defaults on session startup and documenting client-mode requirements.
- Codebase changes: updated `tools/start_raw_shell_server.sh` to run session-local `stty sane -ixon -ixoff` before launching the interactive shell, and expanded `tools/README.md` with explicit telnet line-mode caveat plus `nc`/`socat` character-mode troubleshooting commands.
- Implemented features: fixed RAW shell interactive-control behavior so Ctrl keys and single-character input work reliably in tools like `nano` and `vttest`.
- Codebase changes: removed forced `rawer,echo=0` PTY flags from `tools/start_raw_shell_server.sh`, strengthened session initialization to `stty sane isig icanon echo intr '^C' quit '^\\' -ixon -ixoff`, and updated `tools/README.md` with root-cause notes for `-isig -icanon -echo` symptom states.
- Implemented features: restored reliable multi-host startup behavior for the RAW shell helper by eliminating fragile nested quoting in the `socat EXEC` path.
- Codebase changes: refactored `tools/start_raw_shell_server.sh` to generate a temporary quote-safe launcher script used by `script(1)`/`socat EXEC`, updated startup stty baseline text to `stty sane isig icanon echo -ixon -ixoff`, and aligned `tools/README.md` notes with the new execution model.
- Implemented features: added a dedicated RAW character-mode client helper to reliably test interactive single-key and control-key behavior.
- Codebase changes: created `tools/raw_shell_client.sh` (socat `raw,echo=0` with Ctrl-] escape) and updated `tools/README.md` to recommend it over `nc`/`telnet` when validating full-screen interactive tools like `vttest`.
- Implemented features: fixed boot reliability so startup does not halt when the USB keyboard is not yet enumerated at the first initialization poll.
- Codebase changes: updated `src/TKeyboard.cpp` `CTKeyboard::Initialize()` to always start the keyboard task and allow delayed `ukbd1` enumeration instead of returning failure during early startup.
- Implemented features: restored stable boot and keyboard responsiveness in `wlan_host_autostart=2` shell-client mode by properly initializing the WLAN/network stack and avoiding blocking network processing when uninitialized.
- Codebase changes: updated `src/kernel.cpp` to initialize WLAN firmware + Circle network stack + WPA supplicant in shell-client mode (without enabling telnet), guarded `m_Net.Process()` behind a successful shell-client networking init flag, and added a small retry backoff while waiting for the network to become running.
- Implemented features: eliminated kernel-loop lockups during outbound shell-client connect by moving the blocking TCP `Connect()` into a dedicated `CTWlanHost` task.
- Codebase changes: added `include/TWlanHost.h` + `src/TWlanHost.cpp`, wired shell-client mode delegation into `src/kernel.cpp` and `Makefile`, and removed the legacy shell-client state machine and blocking connect path from `CKernel`.
- Implemented features: fixed shell-client boot assertion by keeping prompt/input gated until a valid remote IP exists so the system no longer copies invalid `CIPAddress` values.
- Codebase changes: `CTWlanHost::Run()` now only copies `m_RemoteIp` when a connection request is pending and `DisplayPromptIfReady()` only runs after networking is ready, preventing early `CIPAddress` assertions while the keyboard prompt waits for input.
- Codebase changes: `CTWlanHost::Run()` now only copies `m_RemoteIp` when a connection request is pending and `DisplayPromptIfReady()` only runs after networking is ready, preventing early `CIPAddress` assertions while the keyboard prompt waits for input.

## 2026-02-22
- Implemented features: improved `start_raw_shell_server.sh` output so it now shows that it's waiting for connections and logs when each shell client attaches, making host-mode feedback obvious.
- Codebase changes: always run `socat` with verbose logging flags when launching the RAW shell server to capture per-client connection events in the helper’s terminal output.
- Implemented features: deferred the shell-client IP prompt until the WLAN stack is ready so keyboard input stays live while the system finishes booting.
- Codebase changes: added a prompt-pending flag plus `DisplayPromptIfReady()` inside `CTWlanHost`, let the `Run()` loop show the prompt only when networking is ready (avoiding keyboard takeover), and ensured `ParseIPv4Address()` preserves the entered octet order so outbound mode targets the intended host.

## 2026-02-23
- Implemented features: kept the WLAN shell-client receiver busy until the socket would block so bursty host output is delivered without waiting for the next kernel tick.
- Codebase changes: updated `CTWlanHost::Tick()` to loop over `MSG_DONTWAIT` receives, handle `NET_ERROR_WOULD_BLOCK` as the normal “no data yet” case, and only close the connection when a remote close or unexpected receive error occurs while logging the error code for diagnostics.
	Also log the `CloseConnection` reason string via `LOGNOTE` so each disconnect is recorded with the triggering message.

## 2026-02-25
- Implemented features: finalized shell-client mode integration around a dedicated `CTWlanHost` runtime task path and aligned local repository hygiene to keep generated artifacts out of everyday commits.
- Codebase changes: updated kernel/config/setup/WLAN host paths plus the new `include/TWlanHost.h` integration and synchronized config templates/bin defaults and README wording, then cleaned transient local artifacts (`build/*`, `bin/kernel.img`, `.DS_Store`) and extended `VT100/.gitignore` with local metadata/build artifact patterns.
